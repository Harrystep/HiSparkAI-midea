
/**
 * Copyright 2022-2023 Huawei Technologies Co., Ltd
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "src/model0/weight0.h"
#include "src/model0/net0.h"

const unsigned char *m0_input0 = 0;
int SetInputs0(const void **inputs, int num) {
  if (inputs == NULL) {
    return RET_ERROR;
  }
  if (num !=1) {
    return RET_ERROR;
  }
	m0_input0 = (unsigned char *)inputs[0];
  return RET_OK;
}
int GetBufferSize0() {
  return 89400;
}
int SetBuffer0( void *buffer) {
  m0_buffer = (unsigned char *)buffer;
  return RET_OK;
}
void FreeResource0() {
  m0_buffer= NULL;
  m0_input0 = NULL;
  void **allocated[] = {

  };
  for (int i = 0; i < 0; ++i) {
    *(allocated[i]) = NULL;
  }
  if (m0_weight != NULL) {
    free(m0_weight);
    m0_weight = NULL;
  }
}
void Execute0(bool train_mode) {
  {
    PackNCHWToNHWCFp32((float *)(m0_input0), (float *)(m0_buffer + 0), 1, 600, 1, 0, 1);
  }
  {
    DoQuantizeFp32ToInt8((float *)(m0_buffer + 0), (int8_t *)(m0_buffer + 2400), 0.02343867719173431396, -1, 600, -128, 127);
  }
  {
    const int32_t unified_scale_int32[16] = {523, 432, 564, 446, 421, 468, 747, 537, 315, 559, 564, 438, 335, 377, 533, 514};
    const int32_t input_shape[4] = {1, 25, 24, 1};
    const int32_t output_shape[4] = {1, 25, 24, 16};
    Conv3x3Int8OptimzedForOutC((int8_t *)(m0_buffer + 2400), (int8_t *)(m0_buffer + 3000), m0_weight4, m0_weight5, -1, unified_scale_int32, -5, 16, input_shape, output_shape);
  }
  {
    DoDequantizeInt8ToFp32((int8_t *)(m0_buffer + 3000), (float *)(m0_buffer + 12600), 0.1525681465864181519, -5, 9600);
  }
  {
    PackNHWCToNCHWFp32((float *)(m0_buffer + 12600), (float *)(m0_buffer + 51000), 1, 600, 16, 0, 1);
  }
}
