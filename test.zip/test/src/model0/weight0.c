
/**
 * Copyright 2022-2023 Huawei Technologies Co., Ltd
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#include "src/model0/weight0.h"
#include <stdio.h>

int  m0_thread_num = 1; 
extern const unsigned char *m0_input0;
int __errno; 
unsigned char * m0_buffer = NULL; 
unsigned char * m0_weight = NULL; 
const int8_t m0_weight4[] = {
40, -11, 52, 122, -19, -19, 127, 62, -38, 36, -31, -31, 16, -127, -114, -37, -67, 21, -79, -122, 127, -20, 6, -123, -47, 10, -100, 26, -41, -20, -41, 127, -1, -73, 56, -84, 14, -127, -86, 13, 48, 11, -7, -20, -96, 
-52, -33, 76, 25, -127, 23, -28, -49, 44, 118, 107, -96, -35, 38, 112, -55, -21, -127, -99, 67, 112, -6, 83, 30, -53, 30, 127, -2, 76, -127, 40, 4, -14, 4, -96, -11, 31, 127, -45, -69, -43, 79, 28, -46, 44, 
8, 84, -61, -28, -34, -127, 26, 23, 0, -16, -95, -28, -23, -54, -11, 27, 127, 12, 13, -4, -99, -1, 3, 127, -10, 16, -2, -68, 66, 44, 46, -53, 81, -81, 34, 127, -81, -46, 8, -41, -127, 6, -87, 39, -75, 
122, -62, -25, 64, -97, 18, 103, -127, 15, 
};

const int32_t m0_weight5[] = {
4, 4, 12, 6, 7, 2, -14, 2, -1, -6, 4, -1, -6, -1, -1, 2, 
};


static size_t PackWeightSize0() {
  size_t w_size = 0;
  return w_size;
}

int Init0(void *weight_buffer, int weight_size) {
  size_t w_size = PackWeightSize0();
  if (w_size > 0) {
    m0_weight = malloc(w_size);
    if (m0_weight == NULL) {
      return RET_ERROR;
    }
    memset(m0_weight, 0, w_size);
  }
  size_t w_offset = 0;
  if (w_size < w_offset) {
    return RET_ERROR;
  }
  return RET_OK;
}

